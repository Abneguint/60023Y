#include "main.h"
#include "lemlib/api.hpp"

// Controller
pros::Controller controller(pros::E_CONTROLLER_MASTER);

// Motor Groups
pros::MotorGroup leftMotors({-11, 12, -13}, pros::MotorGearset::blue); // Left motors
pros::MotorGroup rightMotors({1, -2, 3}, pros::MotorGearset::blue);   // Right motors

// IMU Sensor
pros::Imu imu(7);

// Drivetrain
lemlib::Drivetrain drivetrain(&leftMotors, &rightMotors, 12.2778, lemlib::Omniwheel::NEW_325, 450, 0);

// Other Motors
pros::Motor intakeMotor(4, pros::MotorGearset::green);
pros::Motor conveyorMotor(5, pros::MotorGearset::blue);
pros::Motor clampMotor(6, pros::MotorGearset::green);
pros::Motor ladyBrownMotor(8, pros::MotorGearset::green);

// Pistons
pros::adi::DigitalOut intakeLiftPiston(1);
pros::adi::DigitalOut doinkerDeployPiston(2);

// Chassis Configuration
lemlib::ControllerSettings linearController(10, 0, 3, 3, 1, 100, 3, 500, 20);
lemlib::ControllerSettings angularController(2, 0, 10, 3, 1, 100, 3, 500, 0);

lemlib::Chassis chassis(drivetrain, linearController, angularController, nullptr, nullptr, nullptr);

// Initialization
void initialize() {
    pros::lcd::initialize();
    chassis.calibrate();

    pros::Task screenTask([&]() {
        while (true) {
            pros::lcd::print(0, "X: %f", chassis.getPose().x);
            pros::lcd::print(1, "Y: %f", chassis.getPose().y);
            pros::lcd::print(2, "Theta: %f", chassis.getPose().theta);
            pros::delay(50);
        }
    });
}

// Autonomous
void autonomous() {
    chassis.moveToPose(20, 15, 90, 4000);
    chassis.turnToHeading(180, 2000);
}

// Driver Control
void opcontrol() {
    while (true) {
        // Tank Drive with Curvature Input
        int leftY = controller.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
        int rightY = controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_Y);
        chassis.tank(leftY, rightY);

        // Button Controls
        if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1)) {
            clampMotor.move_velocity(127);
        } else {
            clampMotor.move_velocity(0);
        }

        if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
            intakeLiftPiston.set_value(true);
        } else {
            intakeLiftPiston.set_value(false);
        }

        if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2)) {
            doinkerDeployPiston.set_value(true);
        } else {
            doinkerDeployPiston.set_value(false);
        }

        if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_Y)) {
            ladyBrownMotor.move_velocity(127);
        } else {
            ladyBrownMotor.move_velocity(0);
        }

        // Display IMU Heading on Controller
        double heading = imu.get_heading();
        controller.print(0, 0, "Heading: %.2f", heading);

        pros::delay(10);
    }
}